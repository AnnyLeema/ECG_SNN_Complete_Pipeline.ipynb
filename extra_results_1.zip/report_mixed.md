### Effect of adding rendered PTB-XL images to the training set (test: held-out Kaggle images and PTB-XL fold 10)
PTB-XL test images: 300 (150 Normal, 150 MI); PTB-XL training images added: 500
| Training data | Model | Seeds | Kaggle 4-class acc (%) | Kaggle Normal/MI acc (%) | PTB-XL acc (%) | PTB-XL MI sensitivity (%) | PTB-XL Normal specificity (%) | PTB-XL balanced acc (%) |
|---|---|:---:|:---:|:---:|:---:|:---:|:---:|:---:|
| Kaggle + PTB-XL | S1 | 3 | 94.4 +- 2.8 | 93.9 +- 1.5 | 82.4 +- 1.1 | 76.4 +- 0.4 | 88.4 +- 1.9 | 82.4 +- 1.1 |
| Kaggle + PTB-XL | A4 | 3 | 92.0 +- 2.2 | 93.0 +- 3.0 | 81.8 +- 2.7 | 75.6 +- 12.6 | 88.0 +- 7.2 | 81.8 +- 2.7 |
| Kaggle + PTB-XL | A1 | 3 | 92.0 +- 1.6 | 91.2 +- 1.5 | 84.4 +- 1.3 | 84.7 +- 5.0 | 84.2 +- 5.0 | 84.4 +- 1.3 |