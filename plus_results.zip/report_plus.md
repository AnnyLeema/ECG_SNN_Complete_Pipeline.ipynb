### S1+ variants vs the baseline S1 (5-fold cross-validation, 491 images, same folds)
| Model | Pooled acc (%) [95% CI] | Fold mean +- SD | Macro-F1 | kappa | MI found of 30 | Any-MI sens. | Any-MI spec. | Mean val macro-F1 (selection) | vs S1 baseline: variant right-S1 wrong / variant wrong-S1 right, exact McNemar p |
|---|---|---|---|---|---|---|---|---|---|
| S1 baseline (current, v3) | 86.15 [82.8-88.9] | 86.15 +- 3.14 | 0.766 | 0.789 | 12 | 0.776 | 0.939 | 0.908 |  |
| A4 matched ANN | 89.00 [85.9-91.5] | 89.00 +- 4.18 | 0.839 | 0.834 | 21 | 0.836 | 0.941 | 0.908 |  |
| A1 LW-DN161-like | 90.63 [87.7-92.9] | 90.63 +- 1.52 | 0.871 | 0.857 | 23 | 0.853 | 0.965 | 0.904 |  |
| A2 ResNet50 | 92.87 [90.2-94.8] | 92.87 +- 1.91 | 0.904 | 0.892 | 24 | 0.897 | 0.976 | 0.935 |  |
| P1_focal | 87.78 [84.6-90.4] | 87.77 +- 2.73 | 0.788 | 0.814 | 14 | 0.793 | 0.941 | 0.894 | 19/11, p=0.200 |
| P2_membrane | 87.17 [83.9-89.8] | 87.15 +- 7.25 | 0.801 | 0.807 | 19 | 0.836 | 0.923 | 0.883 | 25/20, p=0.551 |
| P3_distill | 89.21 [86.2-91.7] | 89.20 +- 3.05 | 0.843 | 0.837 | 20 | 0.862 | 0.941 | 0.911 | 29/14, p=0.032 |
| P6_full (all three changes) | 89.00 [85.9-91.5] | 88.99 +- 5.03 | 0.831 | 0.833 | 18 | 0.845 | 0.947 | 0.886 | 26/12, p=0.034 |

Variant chosen by the highest mean VALIDATION macro-F1: **P3_distill** (0.911); baseline S1 validation macro-F1: 0.908

Paired exact McNemar tests of P3_distill against each baseline (Holm-adjusted over 4 comparisons)
| vs | chosen right, other wrong | chosen wrong, other right | p | Holm p |
|---|---|---|---|---|
| S1 | 29 | 14 | 0.0315 | 0.0946 |
| A4 | 16 | 15 | 1.0000 | 1.0000 |
| A1 | 22 | 29 | 0.4011 | 0.8021 |
| A2r | 16 | 34 | 0.0153 | 0.0614 |

Estimated energy of P3_distill: head ratio 0.467, whole pipeline ratio 0.988, spikes/image 5455

NOTE: all variants were run on the test folds; the table lists ALL of them. Only the variant with the best validation score is called S1+. A variant that is better on the test folds but not on validation must not be chosen after the fact.