### 5-fold cross-validation x 1 on all 491 distinct images
| Model | Fold accuracy (mean +- SD) | Pooled accuracy (all 491 images) | 95% Wilson interval | Macro-F1 | Kappa |
|---|:---:|:---:|:---:|:---:|:---:|
| S1 | 86.15 +- 3.14 | 86.15 | 82.8-88.9 | 0.7660 | 0.789 |
| A4 | 89.00 +- 4.18 | 89.00 | 85.9-91.5 | 0.8389 | 0.834 |
| A1 | 90.63 +- 1.52 | 90.63 | 87.7-92.9 | 0.8711 | 0.857 |
| A2r | 92.87 +- 1.91 | 92.87 | 90.2-94.8 | 0.9037 | 0.892 |

### Paired comparison of S1 with the other models (pooled predictions of repeat 0, McNemar exact test; fold accuracies, paired t-test and Wilcoxon)
| S1 vs | S1 right / other wrong | S1 wrong / other right | McNemar p | paired t-test p | Wilcoxon p |
|---|:---:|:---:|:---:|:---:|:---:|
| A4 | 14 | 28 | 0.044 | 0.148 | 0.188 |
| A1 | 16 | 38 | 0.004 | 0.060 | 0.125 |
| A2r | 16 | 49 | 0.000 | 0.003 | 0.062 |

### S1: confusion matrix on all images (rows = true class, columns = predicted)
| True \ Pred | Abnormal Heartbeat | History of MI | Myocardial Infarction | Normal |
|---|:---:|:---:|:---:|:---:|
| Abnormal Heartbeat | 207 | 16 | 2 | 8 |
| History of MI | 9 | 70 | 4 | 3 |
| Myocardial Infarction | 5 | 4 | 12 | 9 |
| Normal | 3 | 1 | 4 | 134 |

### S1: per-class results on all images
| Class | Precision | Sensitivity | Specificity | F1 | Support |
|---|:---:|:---:|:---:|:---:|:---:|
| Abnormal Heartbeat | 0.924 | 0.888 | 0.934 | 0.906 | 233 |
| History of MI | 0.769 | 0.814 | 0.948 | 0.791 | 86 |
| Myocardial Infarction | 0.545 | 0.400 | 0.978 | 0.462 | 30 |
| Normal | 0.870 | 0.944 | 0.943 | 0.905 | 142 |

### Estimated energy (45 nm model, mean over folds)
- S1 whole pipeline 30.27 uJ, matched ANN 30.62 uJ, ratio 0.988
- Spiking head 0.32 uJ against 0.67 uJ for the matched ANN head, ratio 0.474